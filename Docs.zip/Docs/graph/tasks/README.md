# Task Packet Registry

Status: **Operational**  
Graph source: [`../TASK_GRAPH.md`](../TASK_GRAPH.md)  
Template: [`../templates/TASK_PACKET.md`](../templates/TASK_PACKET.md)

## Policy

The task graph is planned globally, but detailed worker packets are created just
in time. Pre-writing every packet would freeze assumptions before dependencies and
contracts are accepted, create stale context, and invite workers to start blocked
work.

The orchestrator creates `Docs/graph/tasks/<NODE-ID>.md` only when:

- all predecessor nodes are accepted;
- required decisions/human gates are recorded;
- consumed contract revisions are known;
- writable ownership is collision-free;
- acceptance criteria and commands are executable from the starting revision;
- the worker environment/device prerequisites are available or not required.

Once accepted and dispatched, a packet is immutable. Scope changes supersede it
with a revision recorded inside the same task history or a new node, rather than
silently editing a worker's contract.

## Current packet index

| Node | Packet | State | Reason |
|---|---|---|---|
| G0 | n/a (DECISION node; no worker packet) | accepted 2026-08-15 | Human product/release owner accepted PRD, spec, and locked architecture in chat; recorded in `../TASK_GRAPH.md` section 8 status-update record |
| FND-001 | [`FND-001.md`](FND-001.md) | accepted 2026-08-15 | Repo initialized on branch `LokiAI-v1.2`, baseline committed and pushed to `https://github.com/The-Shriks/LokiAI-v1.2`. Handoff: [`../handoffs/FND-001-1.md`](../handoffs/FND-001-1.md) |
| FND-002 | [`FND-002.md`](FND-002.md) | accepted | Real toolchain (Node 24.19.0, Rust 1.97.1, pnpm 11.21.0) installed and pinned; `pnpm run verify` passes with real evidence. Handoff: [`../handoffs/FND-002-1.md`](../handoffs/FND-002-1.md) |
| CTR-001 | [`CTR-001.md`](CTR-001.md) | accepted, integrated | Handoff: [`../handoffs/CTR-001-1.md`](../handoffs/CTR-001-1.md). JSON-Schema-vs-zod deviation flagged for human review. |
| DSK-001 | [`DSK-001.md`](DSK-001.md) | accepted, integrated | Handoff: [`../handoffs/DSK-001-1.md`](../handoffs/DSK-001-1.md). Packaged app proven; `pnpm run electron:package` reproducibility gap tracked (§7a). |
| RUN-001 | [`RUN-001.md`](RUN-001.md) | accepted, integrated | Handoff: [`../handoffs/RUN-001-1.md`](../handoffs/RUN-001-1.md). Cargo workspace now has its first real member; guard script's honest-skip no longer applies. |
| DSK-002 | [`DSK-002.md`](DSK-002.md) | accepted, integrated | Handoff: [`../handoffs/DSK-002-1.md`](../handoffs/DSK-002-1.md). 77/77 tests, including sender-spoofing rejection and honest `runtime_unavailable` results pending `RUN-002`. |
| DAT-001 | [`DAT-001.md`](DAT-001.md) | accepted, integrated | Handoff: [`../handoffs/DAT-001-1.md`](../handoffs/DAT-001-1.md). 63/63 tests, no bugs found. `cipher.rs` confirmed a genuine swappable seam, not an invented scheme. |
| CON-001 | [`CON-001.md`](CON-001.md) | accepted, integrated | Handoff: [`../handoffs/CON-001-1.md`](../handoffs/CON-001-1.md). 52/52 tests (44 unit + 8 conformance). |
| MCP-001 | [`MCP-001.md`](MCP-001.md) | accepted, integrated | Handoff: [`../handoffs/MCP-001-1.md`](../handoffs/MCP-001-1.md). Broken `pnpm-workspace.yaml` placeholder + 10 lint findings fixed; 36/36 tests. |
| RUN-002 | [`RUN-002.md`](RUN-002.md) | accepted, integrated | Handoff: [`../handoffs/RUN-002-1.md`](../handoffs/RUN-002-1.md). 6 real bugs found and fixed (incl. a hanging test from a split-pipe half never dropped); 69/69 tests. |
| RUN-003 | [`RUN-003.md`](RUN-003.md) | accepted, integrated | Handoff: [`../handoffs/RUN-003-1.md`](../handoffs/RUN-003-1.md). Real IPC+storage composition wired into `Run` mode's shipped default; `--supervised` userland crash-recovery mode; discovery `Healthy` only after a real handshake+ping (spot-checked). Interim plain-file IPC token storage (not yet DPAPI-wrapped) flagged, deferred to `DAT-002` — not a new gap. |
| CON-002 | [`CON-002.md`](CON-002.md) | accepted, integrated | Handoff: [`../handoffs/CON-002-1.md`](../handoffs/CON-002-1.md). 35/35 tests (26 unit + 9 integration); own `TestConnector` used in place of `CON-001`'s private `MockConnector` (flagged, accepted). |
| MON-001 | [`MON-001.md`](MON-001.md) | accepted, integrated | Handoff: [`../handoffs/MON-001-1.md`](../handoffs/MON-001-1.md). 58/58 tests (42 unit + 16 integration). **Flagged deviation:** telemetry lives in its own self-contained second SQLite database, not `loki-storage`'s — the packet's literal migration instruction and its forbidden-scope boundary were mutually exclusive as written (verified against actual source); open ADR-level question for a human/follow-up node (§9 of the handoff), also affects `DAT-002` encryption scope. |
| JOB-001 | [`JOB-001.md`](JOB-001.md) | accepted, integrated | Handoff: [`../handoffs/JOB-001-1.md`](../handoffs/JOB-001-1.md). 44/44 tests (25 unit + 19 integration); in-memory per-process lease + `JobEngine::reconcile()` crash-recovery, not a new SQLite table (flagged, accepted). |
| MCP-002 | [`MCP-002.md`](MCP-002.md) | accepted, integrated | Handoff: [`../handoffs/MCP-002-1.md`](../handoffs/MCP-002-1.md). 85/85 tests. `loki_list_devices`/`loki_get_device_health` honestly report `runtime_unavailable` — no real device data path exists yet (RUN-003's IPC/registry wiring for MCP consumption is separate scope); verified this is a genuine gap, not a shortcut. |
| BLD-001 | [`BLD-001.md`](BLD-001.md) | blocked / explicitly deferred 2026-08-24 | `BLD-001-CORR-001-R1` requires a new accepted containment-workspace design before hostile-fixture evidence can run. It is not accepted and must not be used to satisfy the Part One gate. |
| INC-001 | [`INC-001.md`](INC-001.md) | accepted, integrated | Handoff: [`../handoffs/INC-001-1.md`](../handoffs/INC-001-1.md). Production domain/storage logic is integrated, but real connector ingestion and runtime composition remain correction work. |
| MON-002 | [`MON-002.md`](MON-002.md) | accepted, integrated | Handoff: [`../handoffs/MON-002-1.md`](../handoffs/MON-002-1.md). 34 unit + 20 integration tests. `ScopeSelector` matches `DeviceId`s mechanically (no real workspace/device-ownership model yet, `AUTH-001`/`ENR-001` still blocked) — resolves the packet's own stop condition, verified as legitimate not evasive. Second `rusqlite::Connection` into `MON-001`'s same self-contained database, proven safe by a dedicated test. |
| DAT-002 | [`DAT-002.md`](DAT-002.md) | integrated checkpoint, blocked | Current-user SQLCipher/DPAPI paths pass; `DAT-002-REV-001` is performing the missing independent review. Second-Windows-identity evidence remains mandatory. |
| `P1-GRAPH-AUD-001` | [`P1-GRAPH-AUD-001.md`](P1-GRAPH-AUD-001.md) | `NEEDS_REPLAN` | Independent audit produced the accepted correction frontier and ADR-0003. |
| `P1-RUNTIME-AUD-001` | [`P1-RUNTIME-AUD-001.md`](P1-RUNTIME-AUD-001.md) | complete | No architecture change required; seven production integration nodes defined. |
| `DAT-002-REV-001` | [`DAT-002-REV-001.md`](DAT-002-REV-001.md) | `FAILED_VERIFICATION` | Two critical and seven high encrypted-data lifecycle findings; review recorded under W4 evidence. |
| `DAT-002-CORR-001` | [`DAT-002-CORR-001.md`](DAT-002-CORR-001.md) | `NEEDS_REPLAN` | Required lifecycle exposed the SQLCipher secure-memory quota failure; ADR-0005 replaces the unsafe allocation model without accepting this failed node. |
| `DAT-002-MEM-ADR-001` | ADR-0005 decision record | accepted 2026-08-24 | Fixed verified secure arena accepted for implementation; operational Windows/VM validation remains separately gated. |
| `DAT-002-MEM-CODE-001` | [`DAT-002-MEM-CODE-001.md`](DAT-002-MEM-CODE-001.md) | ready | Accepted code packet at `0bd4a704`; no elevation, VM, signing credential, or guessed production bounds are authorized. |
| `DAT-002-MEM-HOST-VERIFY-001` | packet pending | `BLOCKED_DEPENDENCY` | Requires CODE plus exact VM/signing operation approval and an approved supported-host environment. |
| `DAT-002-MEM-REV-001` | packet pending | proposed | Independent review follows accepted CODE and HOST-VERIFY evidence. |
| `DAT-002-MEM-IMPL-001` | packet pending | proposed | Final integration/acceptance cannot occur from code tests alone. |
| `P1-RPC-CONTRACT-001` | [`P1-RPC-CONTRACT-001.md`](P1-RPC-CONTRACT-001.md) | `NEEDS_REPLAN` | REV-004 proved IPC cannot enforce the durable mutation boundary; safe transport work remains salvage evidence only. |
| `P1-MUTATION-SEM-ADR-001` | [`P1-MUTATION-SEM-ADR-001.md`](P1-MUTATION-SEM-ADR-001.md) | `BLOCKED_DEPENDENCY` | ADR-0006 needs the exact human security/public-contract semantics decision. |
| `BLD-ARCH-ADR-001` | [`BLD-ARCH-ADR-001.md`](BLD-ARCH-ADR-001.md) | accepted 2026-08-24 | ADR-0004 Design A accepted for implementation; every elevated/VHDX operation remains separately gated. |
| `BLD-001-R2-CODE` | [`BLD-001-R2-CODE.md`](BLD-001-R2-CODE.md) | ready | Accepted packet at `0bd4a704`; no VHDX invocation, elevation, install, signing credential, or host mutation. |
| `BLD-001-R2-HOST-VERIFY` | packet pending | `BLOCKED_DEPENDENCY` | Requires accepted R2 code plus separate exact VHDX/elevation approval and an approved signer/provisioning environment. |
| `CON-003-PRE-001` | [`CON-003-PRE-001.md`](CON-003-PRE-001.md) | accepted | Read-only audit exit passed; COM5 is only a transport candidate and exact SKU remains unverified. |
| `CON-ID-CONTRACT-001` | [`CON-ID-CONTRACT-001.md`](CON-ID-CONTRACT-001.md) | ready | Protocol v1.0.0 accepted; no COM open, reset, flash or device configuration is authorized. |
| Remaining Part One (W0–W6) nodes | created just-in-time as each becomes dependency-ready | correction program active | Continue every ready local branch. Cloud alone remains deferred. Device-changing operations and locked-boundary decisions retain their exact human gates. |
| `P1-INT-001` (Part One completion gate) | [`P1-INT-001.md`](P1-INT-001.md) | `NEEDS_REPLAN` | Prior package-test evidence remains valid but did not prove production composition or the required connector/build/artifact/operation/deployment paths. |
| Part Two (`UI-001` and W7–W10 descendants) | not created | dependency + human-approval pending | Blocked on `P1-INT-001` acceptance **and** a separate human go-ahead per `../TASK_GRAPH.md` section 1a; do not create Part Two packets before both exist |

## Naming and handoff

- Task packet: `Docs/graph/tasks/<NODE-ID>.md`
- Worker handoff: `Docs/graph/handoffs/<NODE-ID>-<ATTEMPT>.md`
- Verification evidence index: `Docs/graph/evidence/<wave>/<NODE-ID>/README.md`
- Independent review: `Docs/graph/evidence/<wave>/<NODE-ID>/REVIEW-<TYPE>.md`
- Large/sensitive test output: protected external artifact reference plus digest,
  never committed raw by default.

Only the orchestrator updates this registry and `Docs/graph/TASK_GRAPH.md` status.
